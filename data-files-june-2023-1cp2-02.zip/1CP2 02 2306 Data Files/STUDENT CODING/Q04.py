# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------
# =====> Write your code here

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------
# =====> Write your code here
# Take three decimal inputs from the user

# Check for invalid inputs, using relational and logical operators

# Display an error message if any input is invalid
# Invalid input should not be processed

# Process all valid inputs
# Calculate the area of the triangle

# Display the area of the triangle, rounded to two decimal places

# Calculate the volume of the prism

# Display the volume of the prism using the <string>.format() function
# in eight columns with two decimal places

# In all cases, display a goodbye message just before terminating

